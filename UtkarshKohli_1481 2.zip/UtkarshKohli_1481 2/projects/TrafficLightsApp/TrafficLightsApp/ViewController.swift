//
//  ViewController.swift
//  TrafficLightsApp
//
//  Created by student on 27/02/24.
//

import UIKit

class ViewController: UIViewController {

//    @IBOutlet weak var destTitleField: UITextField!
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do any additional setup after loading the view.
//    }
//    
//    @IBAction func unwindToRed(unwindSeque: UIStoryboardSegue){
//        print("I am back to red")
//    }

}

