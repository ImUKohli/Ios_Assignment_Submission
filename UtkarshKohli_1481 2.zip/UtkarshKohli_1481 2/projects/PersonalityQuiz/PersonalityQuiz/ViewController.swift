//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by student on 05/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

